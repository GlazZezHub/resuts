function mcpaint:settings/internal/client/set with entity @s

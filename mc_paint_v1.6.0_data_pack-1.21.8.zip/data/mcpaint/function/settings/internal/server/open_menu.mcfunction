data modify storage mcpaint:calc internal.settings.dialog set value {inputs: []}
data modify storage mcpaint:calc internal.settings.dialog.inputs append value {type: "minecraft:boolean", key: "allow_decode", label: {translate: "mcpaint.settings.server.allow_decode.title", extra: [{text: "\n"}, {translate: "mcpaint.settings.server.allow_decode.info", color: "gray", italic: true}]}, initial: 0b}
data modify storage mcpaint:calc internal.settings.dialog.inputs[-1].initial set from storage mcpaint:calc api.settings.server.allow_decode
function mcpaint:settings/internal/server/open_menu/macro with storage mcpaint:calc internal.settings.dialog

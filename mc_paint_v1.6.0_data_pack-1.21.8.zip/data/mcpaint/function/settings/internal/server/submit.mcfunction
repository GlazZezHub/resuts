$data modify storage mcpaint:calc api.settings.server set value {allow_decode:$(allow_decode)}

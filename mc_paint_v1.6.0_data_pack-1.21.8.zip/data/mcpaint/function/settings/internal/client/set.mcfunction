$data modify storage mcpaint:calc internal.settings.clients."$(UUID)" set from storage mcpaint:calc api.settings.client 

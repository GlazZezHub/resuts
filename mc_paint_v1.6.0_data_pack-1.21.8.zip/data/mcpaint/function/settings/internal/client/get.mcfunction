$data modify storage mcpaint:calc api.settings.client merge from storage mcpaint:calc internal.settings.clients."$(UUID)"

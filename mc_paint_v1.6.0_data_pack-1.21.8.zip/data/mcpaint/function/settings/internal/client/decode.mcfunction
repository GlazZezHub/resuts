function mcpaint:settings/api/get_client
scoreboard players operation #temp mcpaint.calc = @s mcpaint.settings
scoreboard players set #temp2 mcpaint.calc 10
scoreboard players operation #temp mcpaint.calc %= #temp2 mcpaint.calc
scoreboard players set #temp2 mcpaint.calc 1
scoreboard players operation #temp mcpaint.calc /= #temp2 mcpaint.calc
execute if score #temp mcpaint.calc matches 2 run data modify storage mcpaint:calc api.settings.client.egg_banter set value 1b
execute if score #temp mcpaint.calc matches 3 run data modify storage mcpaint:calc api.settings.client.egg_banter set value 0b
scoreboard players operation #temp mcpaint.calc = @s mcpaint.settings
scoreboard players set #temp2 mcpaint.calc 100
scoreboard players operation #temp mcpaint.calc %= #temp2 mcpaint.calc
scoreboard players set #temp2 mcpaint.calc 10
scoreboard players operation #temp mcpaint.calc /= #temp2 mcpaint.calc
execute if score #temp mcpaint.calc matches 2 run data modify storage mcpaint:calc api.settings.client.protect_studio set value 1b
execute if score #temp mcpaint.calc matches 3 run data modify storage mcpaint:calc api.settings.client.protect_studio set value 0b
scoreboard players operation #temp mcpaint.calc = @s mcpaint.settings
scoreboard players set #temp2 mcpaint.calc 1000
scoreboard players operation #temp mcpaint.calc %= #temp2 mcpaint.calc
scoreboard players set #temp2 mcpaint.calc 100
scoreboard players operation #temp mcpaint.calc /= #temp2 mcpaint.calc
execute if score #temp mcpaint.calc matches 2 run data modify storage mcpaint:calc api.settings.client.send_rp_message set value 1b
execute if score #temp mcpaint.calc matches 3 run data modify storage mcpaint:calc api.settings.client.send_rp_message set value 0b
function mcpaint:settings/api/set_client

function mcpaint:settings/api/get_client
data modify storage mcpaint:calc internal.settings.dialog set value {inputs: []}
data modify storage mcpaint:calc internal.settings.dialog.inputs append value {type: "minecraft:boolean", key: "send_rp_message", on_true: "2", on_false: "3", label: {text: "Send resource pack message", extra: [{text: "\u200c", bold: true}]}, initial: 0b}
data modify storage mcpaint:calc internal.settings.dialog.inputs[-1].initial set from storage mcpaint:calc api.settings.client.send_rp_message
data modify storage mcpaint:calc internal.settings.dialog.inputs append value {type: "minecraft:boolean", key: "protect_studio", on_true: "2", on_false: "3", label: {text: "Protect Studio", extra: [{text: " \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c", bold: true}]}, initial: 0b}
data modify storage mcpaint:calc internal.settings.dialog.inputs[-1].initial set from storage mcpaint:calc api.settings.client.protect_studio
data modify storage mcpaint:calc internal.settings.dialog.inputs append value {type: "minecraft:boolean", key: "egg_banter", on_true: "2", on_false: "3", label: {text: "Egg banter", extra: [{text: " \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c \u200c\u200c\u200c\u200c\u200c", bold: true}]}, initial: 0b}
data modify storage mcpaint:calc internal.settings.dialog.inputs[-1].initial set from storage mcpaint:calc api.settings.client.egg_banter
function mcpaint:settings/internal/client/open_menu/macro with storage mcpaint:calc internal.settings.dialog

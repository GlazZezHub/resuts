execute if score #studio.tools.register_phase mcpaint.calc matches 1 run function mcpaint:studio/internal/tools/register/phase_1
execute if score #studio.tools.register_phase mcpaint.calc matches 2 run function mcpaint:studio/internal/tools/register/phase_2

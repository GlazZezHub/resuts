$function mcpaint:studio/ui/$(name)/api/event/saved

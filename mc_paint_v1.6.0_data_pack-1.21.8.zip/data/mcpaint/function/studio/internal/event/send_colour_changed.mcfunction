$function mcpaint:studio/ui/$(name)/api/event/colour_changed

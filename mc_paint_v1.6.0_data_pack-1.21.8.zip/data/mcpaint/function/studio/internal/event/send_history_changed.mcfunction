$function mcpaint:studio/ui/$(name)/api/event/history_changed

$function mcpaint:studio/ui/$(name)/api/click

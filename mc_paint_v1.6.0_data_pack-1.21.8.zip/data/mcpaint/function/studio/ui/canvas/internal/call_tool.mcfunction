$function mcpaint:studio/tool/$(id)/api/click_canvas

scoreboard players set #studio.ui_element.focused_child.make_sound mcpaint.calc 0
scoreboard players set #studio.ui_element.focused_child.can_click mcpaint.calc 1
scoreboard players set #studio.ui_element.focused_child.can_spam_click mcpaint.calc 1

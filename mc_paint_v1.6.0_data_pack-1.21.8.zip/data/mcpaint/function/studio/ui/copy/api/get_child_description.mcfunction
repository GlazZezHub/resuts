execute if score #studio.ui_element.focused_child mcpaint.calc matches 1 run data modify storage mcpaint:calc internal.studio.title set value {translate: "mcpaint.ui.button.cancel"}
execute if score #studio.ui_element.focused_child mcpaint.calc matches 2 run data modify storage mcpaint:calc internal.studio.title set value {translate: "mcpaint.ui.button.copy_to_book"}
execute if score #studio.ui_element.focused_child mcpaint.calc matches 3 run data modify storage mcpaint:calc internal.studio.title set value {translate: "mcpaint.ui.button.copy_to_clipboard"}

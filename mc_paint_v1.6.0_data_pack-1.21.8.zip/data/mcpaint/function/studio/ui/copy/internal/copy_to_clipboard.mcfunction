$tellraw @s {"translate":"mcpaint.ui.button.copy_to_clipboard.chat","click_event":{"action":"copy_to_clipboard","value":"$(clipboard_text)"},"color":"aqua","underlined":true}

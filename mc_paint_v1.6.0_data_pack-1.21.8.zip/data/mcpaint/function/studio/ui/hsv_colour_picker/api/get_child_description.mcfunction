execute if score #studio.ui_element.focused_child mcpaint.calc matches 1 run data modify storage mcpaint:calc internal.studio.title set value {translate: "mcpaint.ui.button.hue_ring"}
execute if score #studio.ui_element.focused_child mcpaint.calc matches 2 run data modify storage mcpaint:calc internal.studio.title set value {translate: "mcpaint.ui.button.sv_square"}
execute if score #studio.ui_element.focused_child mcpaint.calc matches 3 run data modify storage mcpaint:calc internal.studio.title set value {translate: "mcpaint.ui.button.foreground_colour"}
execute if score #studio.ui_element.focused_child mcpaint.calc matches 4 run data modify storage mcpaint:calc internal.studio.title set value {translate: "mcpaint.ui.button.background_colour"}
execute if score #studio.ui_element.focused_child mcpaint.calc matches 5 run data modify storage mcpaint:calc internal.studio.title set value {translate: "mcpaint.ui.button.transparent_colour"}
execute if score #studio.ui_element.focused_child mcpaint.calc matches 6 run data modify storage mcpaint:calc internal.studio.title set value {translate: "mcpaint.ui.button.swap_fg_bg_colour"}

execute if score #studio.ui_element.u.px mcpaint.calc matches 15..46 if score #studio.ui_element.v.px mcpaint.calc matches 4..22 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 1
execute if score #studio.ui_element.u.px mcpaint.calc matches 49..80 if score #studio.ui_element.v.px mcpaint.calc matches 4..22 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 2
execute if score #studio.ui_element.u.px mcpaint.calc matches 3..20 if score #studio.ui_element.v.px mcpaint.calc matches 57..74 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 3
execute if score #studio.ui_element.u.px mcpaint.calc matches 39..47 if score #studio.ui_element.v.px mcpaint.calc matches 68..74 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 11
execute if score #studio.ui_element.u.px mcpaint.calc matches 39..47 if score #studio.ui_element.v.px mcpaint.calc matches 60..66 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 12
execute if score #studio.ui_element.u.px mcpaint.calc matches 67..75 if score #studio.ui_element.v.px mcpaint.calc matches 68..74 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 13
execute if score #studio.ui_element.u.px mcpaint.calc matches 67..75 if score #studio.ui_element.v.px mcpaint.calc matches 60..66 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 14
execute if score #studio.ui_element.u.px mcpaint.calc matches 22..30 if score #studio.ui_element.v.px mcpaint.calc matches 50..56 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 15
execute if score #studio.ui_element.u.px mcpaint.calc matches 22..30 if score #studio.ui_element.v.px mcpaint.calc matches 42..48 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 16
execute if score #studio.ui_element.u.px mcpaint.calc matches 22..30 if score #studio.ui_element.v.px mcpaint.calc matches 34..40 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 17
execute if score #studio.ui_element.u.px mcpaint.calc matches 22..30 if score #studio.ui_element.v.px mcpaint.calc matches 26..32 run scoreboard players set #studio.ui_element.focused_child mcpaint.calc 18
execute if score #studio.ui_element.focused_child mcpaint.calc matches 1.. run scoreboard players set #studio.ui_element.focused_child.can_click mcpaint.calc 1
execute if score #studio.ui_element.focused_child mcpaint.calc matches 10.. run scoreboard players set #studio.ui_element.focused_child.can_spam_click_when_sneaking mcpaint.calc 1
execute if score #studio.ui_element.focused_child mcpaint.calc matches 1.. run scoreboard players set #studio.ui_element.focused_child.has_description mcpaint.calc 1

execute as @p[predicate=mcpaint:same_session] unless predicate mcpaint:can_craft_custom_painting run return run tellraw @s {translate: "mcpaint.error.cannot_craft_custom_painting", color: "red", with: [{translate: "item.minecraft.painting"}]}
execute as @p[predicate=mcpaint:same_session] run function mcpaint:custom_painting/api/give with storage mcpaint:calc internal.studio.ui.data.filepath
execute if score #database.found mcpaint.calc matches 1 as @p[predicate=mcpaint:same_session] unless entity @s[gamemode=creative] run clear @s painting 1

execute if score #studio.ui_element.focused_child mcpaint.calc matches 1 run function mcpaint:studio/ui/error_message/internal/confirm with entity @s data
execute if score #studio.ui_element.focused_child mcpaint.calc matches 2 run function mcpaint:studio/internal/ui/close

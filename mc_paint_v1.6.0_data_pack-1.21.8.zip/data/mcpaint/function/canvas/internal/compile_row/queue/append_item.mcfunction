$data modify storage mcpaint:calc internal.canvas.compile_row.queue set value "$(queue)$(item)"

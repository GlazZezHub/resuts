$data modify storage mcpaint:calc api.canvas.set_pixel.previous_colour set from storage mcpaint:calc api.canvas.canvas.colour_array[$(u)][$(v)]
$execute store success score #canvas.set_pixel.changed mcpaint.calc run data modify storage mcpaint:calc api.canvas.canvas.colour_array[$(u)][$(v)] set value $(colour)

data modify storage mcpaint:calc internal.canvas.compile_row set value {output: "", queue: ""}
data modify storage mcpaint:calc internal.canvas.compile_row.input set from storage mcpaint:calc api.canvas.compile_row
function mcpaint:canvas/internal/compile_row/start
data modify storage mcpaint:calc api.canvas.compiled_row set from storage mcpaint:calc internal.canvas.compile_row.output

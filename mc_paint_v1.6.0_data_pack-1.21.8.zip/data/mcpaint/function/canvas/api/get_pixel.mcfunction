function mcpaint:canvas/internal/get_pixel with storage mcpaint:calc api.canvas.get_pixel

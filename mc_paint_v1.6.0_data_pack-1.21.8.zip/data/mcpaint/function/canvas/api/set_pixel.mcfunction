function mcpaint:canvas/api/get_info
function mcpaint:canvas/internal/set_pixel with storage mcpaint:calc api.canvas.set_pixel
execute if score #canvas.set_pixel.changed mcpaint.calc matches 1 run data modify storage mcpaint:calc api.canvas.recompile_indices set value []
execute if score #canvas.set_pixel.changed mcpaint.calc matches 1 run data modify storage mcpaint:calc api.canvas.recompile_indices append from storage mcpaint:calc api.canvas.set_pixel.u
execute if score #canvas.set_pixel.changed mcpaint.calc matches 1 run function mcpaint:canvas/api/recompile_indexed_rows

data modify storage mcpaint:calc api.canvas.text set value {storage: "mcpaint:calc", nbt: "api.canvas.canvas.resolved_text", interpret: true, font: "mcpaint:ink/fullbright"}

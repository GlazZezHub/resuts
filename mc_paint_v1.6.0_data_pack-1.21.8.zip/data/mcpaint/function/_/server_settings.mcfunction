function mcpaint:settings/api/trigger_server

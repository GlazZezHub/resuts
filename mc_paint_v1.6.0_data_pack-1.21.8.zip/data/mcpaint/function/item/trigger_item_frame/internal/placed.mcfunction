data modify storage mcpaint:calc api.trigger_item_frame.trigger set from entity @s Item.components."minecraft:custom_data".mcpaint
execute store result score #temp mcpaint.calc run data get entity @s Facing
execute if score #temp mcpaint.calc matches 0 run data modify storage mcpaint:calc api.trigger_item_frame.trigger merge value {vertical_direction: "down", facing: "down", facing_axis: "y", rotation: [0.0f, 90.0f]}
execute if score #temp mcpaint.calc matches 1 run data modify storage mcpaint:calc api.trigger_item_frame.trigger merge value {vertical_direction: "up", facing: "up", facing_axis: "y", rotation: [0.0f, -90.0f]}
execute if score #temp mcpaint.calc matches 2 run data modify storage mcpaint:calc api.trigger_item_frame.trigger merge value {vertical_direction: "level", facing: "north", facing_axis: "z", rotation: [180.0f, 0.0f]}
execute if score #temp mcpaint.calc matches 3 run data modify storage mcpaint:calc api.trigger_item_frame.trigger merge value {vertical_direction: "level", facing: "south", facing_axis: "z", rotation: [0.0f, 0.0f]}
execute if score #temp mcpaint.calc matches 4 run data modify storage mcpaint:calc api.trigger_item_frame.trigger merge value {vertical_direction: "level", facing: "west", facing_axis: "x", rotation: [90.0f, 0.0f]}
execute if score #temp mcpaint.calc matches 5 run data modify storage mcpaint:calc api.trigger_item_frame.trigger merge value {vertical_direction: "level", facing: "east", facing_axis: "x", rotation: [270.0f, 0.0f]}
execute if score #temp mcpaint.calc matches 0..1 run function mcpaint:util/api/horizontal_direction_to_rotation
execute if score #temp mcpaint.calc matches 0..1 run data modify storage mcpaint:calc api.trigger_item_frame.trigger.rotation[0] set from storage mcpaint:calc api.util.rotation[0]
scoreboard players set #trigger_item_frame.can_place mcpaint.calc 1
function mcpaint:item/trigger_item_frame/internal/trigger with storage mcpaint:calc api.trigger_item_frame.trigger
kill @s

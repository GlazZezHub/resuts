$particle minecraft:entity_effect{color:$(rgba)} ~ ~0.5 ~ 0 0 0 0.1 5

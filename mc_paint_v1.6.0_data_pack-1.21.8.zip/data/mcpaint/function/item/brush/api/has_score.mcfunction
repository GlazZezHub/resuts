scoreboard players remove @s mcpaint.using_brush 1

$function mcpaint:database/api/get_work {author:$(author),name:"$(name)"}
execute if score #database.found mcpaint.calc matches 0 run return fail
data modify storage mcpaint:calc api.database.features set value {}
$data modify storage mcpaint:calc api.database.features.author set from storage mcpaint:database authors[{sUUID:"$(author)"}].name
data modify storage mcpaint:calc api.database.features.title set from storage mcpaint:calc api.database.work.name
data modify storage mcpaint:calc api.canvas.canvas set from storage mcpaint:calc api.database.work.canvas
function mcpaint:canvas/api/get_info
execute store result storage mcpaint:calc api.database.features.width_px int 1 run scoreboard players get #canvas.width_px mcpaint.calc
execute store result storage mcpaint:calc api.database.features.height_px int 1 run scoreboard players get #canvas.height_px mcpaint.calc
execute store result storage mcpaint:calc api.database.features.width_blocks int 1 run scoreboard players get #canvas.width_blocks mcpaint.calc
execute store result storage mcpaint:calc api.database.features.height_blocks int 1 run scoreboard players get #canvas.height_blocks mcpaint.calc
execute store result storage mcpaint:calc api.database.features.text_size int 1 run scoreboard players get #canvas.text_size mcpaint.calc
scoreboard players operation #api.util.bytes mcpaint.calc = #canvas.text_size mcpaint.calc
function mcpaint:util/api/format_bytes
data modify storage mcpaint:calc api.database.features.text_size_formatted set from storage mcpaint:calc api.util.str

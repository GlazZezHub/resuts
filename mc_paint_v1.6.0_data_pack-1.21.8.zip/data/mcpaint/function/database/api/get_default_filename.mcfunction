data modify storage mcpaint:calc api.database.filename set value ""
$function mcpaint:database/internal/get_work_names {author:$(author)}
data modify storage mcpaint:calc internal.database.get_default_filename set value {i: 1, prefix: "New Painting "}
scoreboard players set #database.i mcpaint.calc 1
function mcpaint:database/internal/get_default_filename/loop with storage mcpaint:calc internal.database.get_default_filename

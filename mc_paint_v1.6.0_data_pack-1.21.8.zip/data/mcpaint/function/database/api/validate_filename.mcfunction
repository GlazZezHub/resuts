scoreboard players set #database.valid mcpaint.calc 1
data modify storage mcpaint:calc internal.database.validate_filename set value {}
data modify storage mcpaint:calc internal.database.validate_filename.original set from storage mcpaint:calc api.database.filename
execute store result score #database.temp mcpaint.calc run data get storage mcpaint:calc internal.database.validate_filename.original
execute unless score #database.temp mcpaint.calc matches 1..24 run scoreboard players set #database.valid mcpaint.calc 0
execute unless score #database.temp mcpaint.calc matches 1..24 run data modify storage mcpaint:calc api.database.error_message set value {translate: "mcpaint.error.invalid_filename_length", with: [1, 24]}
execute if score #database.valid mcpaint.calc matches 0 run return fail
function mcpaint:database/internal/validate_filename/quotes with storage mcpaint:calc internal.database.validate_filename
execute store success score #database.temp mcpaint.calc run data modify storage mcpaint:calc internal.database.validate_filename.double_quotes set from storage mcpaint:calc internal.database.validate_filename.original
execute if score #database.temp mcpaint.calc matches 1 run scoreboard players set #database.valid mcpaint.calc 0
execute store success score #database.temp mcpaint.calc run data modify storage mcpaint:calc internal.database.validate_filename.single_quotes set from storage mcpaint:calc internal.database.validate_filename.original
execute if score #database.temp mcpaint.calc matches 1 run scoreboard players set #database.valid mcpaint.calc 0
execute if score #database.valid mcpaint.calc matches 0 run data modify storage mcpaint:calc api.database.error_message set value {translate: "mcpaint.error.invalid_filename_chars"}
execute if score #database.valid mcpaint.calc matches 0 run return fail
data modify storage mcpaint:calc internal.database.validate_filename.queue set from storage mcpaint:calc internal.database.validate_filename.original
execute store result score #database.i mcpaint.calc run data get storage mcpaint:calc internal.database.validate_filename.original
execute if score #database.i mcpaint.calc matches 1.. run function mcpaint:database/internal/validate_filename/iterate_chars
execute if score #database.valid mcpaint.calc matches 0 run data modify storage mcpaint:calc api.database.error_message set value {translate: "mcpaint.error.invalid_filename_chars"}
execute if score #database.valid mcpaint.calc matches 0 run return fail

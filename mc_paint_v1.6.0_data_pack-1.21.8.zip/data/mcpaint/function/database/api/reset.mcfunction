data modify storage mcpaint:database authors set value []

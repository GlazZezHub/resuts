$execute store success score #database.found mcpaint.calc run data remove storage mcpaint:database authors[{sUUID:"$(author)"}].works[{name:"$(name)"}]

$data modify storage mcpaint:calc api.database.author_name set from storage mcpaint:database authors[{sUUID:"$(author)"}].name

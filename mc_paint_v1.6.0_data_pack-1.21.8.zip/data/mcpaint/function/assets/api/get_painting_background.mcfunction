data modify storage mcpaint:calc api.assets.model set value {surface: 0.0625f, transformation: {left_rotation: [0.0f, 0.0f, 0.0f, 1.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], translation: [0.0f, 0.0f, 0.5f], scale: [1.0f, 1.0f, 1.0f]}}
data modify storage mcpaint:calc internal.assets.lookup set value {variant: "canvas", z_origin: 0.0f}
data modify storage mcpaint:calc internal.assets.lookup.variant set from storage mcpaint:calc api.assets.get_model.variant
execute unless data storage mcpaint:calc api.assets.get_model{variant: "empty"} run function mcpaint:assets/internal/lookup with storage mcpaint:calc internal.assets.lookup
data modify storage mcpaint:calc api.assets.model.item set value {id: "minecraft:poisonous_potato", count: 1, components: {"minecraft:custom_model_data": {floats: [1.0f, 1.0f]}}}
data modify storage mcpaint:calc api.assets.model.item.components."minecraft:item_model" set from storage mcpaint:calc internal.assets.lookup.return.item_model
execute store result storage mcpaint:calc api.assets.model.item.components."minecraft:custom_model_data".floats[0] float 1 run data get storage mcpaint:calc api.assets.get_model.width
execute store result storage mcpaint:calc api.assets.model.item.components."minecraft:custom_model_data".floats[1] float 1 run data get storage mcpaint:calc api.assets.get_model.height
data modify storage mcpaint:calc api.assets.model.surface set from storage mcpaint:calc internal.assets.lookup.return.surface
execute unless data storage mcpaint:calc internal.assets.lookup.return.item_model run data modify storage mcpaint:calc api.assets.model merge value {transformation: {scale: [0.0f, 0.0f, 0.0f]}, surface: 0.0f}
execute store result score #assets.z_origin mcpaint.calc run data get storage mcpaint:calc api.assets.get_model.z_origin 10000
execute store result score #assets.z mcpaint.calc run data get storage mcpaint:calc api.assets.model.surface 10000
execute if data storage mcpaint:calc api.assets.get_model.enforce_surface run function mcpaint:assets/internal/enforce_surface
scoreboard players operation #assets.z mcpaint.calc -= #assets.z_origin mcpaint.calc
execute store result storage mcpaint:calc api.assets.model.surface float 0.0001 run scoreboard players get #assets.z mcpaint.calc
execute store result score #assets.z mcpaint.calc run data get storage mcpaint:calc api.assets.model.transformation.translation[2] 10000
scoreboard players operation #assets.z mcpaint.calc -= #assets.z_origin mcpaint.calc
execute store result storage mcpaint:calc api.assets.model.transformation.translation[2] float 0.0001 run scoreboard players get #assets.z mcpaint.calc

$data modify storage mcpaint:calc internal.assets.lookup.return set from storage mcpaint:calc internal.assets.painting_backgrounds[{variant:"$(variant)"}]

$advancement grant @s only $(grant_advancement)

scoreboard players operation math.b64.decoder.buffer_size eroxified2.api = #math.b64.decoder.buffer_size eroxified2.internal

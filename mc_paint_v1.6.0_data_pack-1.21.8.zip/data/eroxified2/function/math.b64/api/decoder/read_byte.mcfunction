scoreboard players set math.b64.decoder.eof eroxified2.api 0
function eroxified2:math.b64/internal/decoder/next_char

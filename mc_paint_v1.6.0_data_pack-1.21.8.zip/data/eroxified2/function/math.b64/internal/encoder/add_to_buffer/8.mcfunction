$data modify storage eroxified2:internal math.b64.encoder.buffer.buffer set value "$(buffer)$(char0)$(char1)$(char2)$(char3)$(char4)$(char5)$(char6)$(char7)"
scoreboard players set #math.b64.encoder.batch_size eroxified2.internal 0

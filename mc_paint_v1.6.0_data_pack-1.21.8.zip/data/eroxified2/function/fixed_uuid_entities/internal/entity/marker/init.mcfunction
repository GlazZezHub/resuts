execute as c9e31925-0471-4244-834f-c92ea4c7b87b at @s unless loaded ~ ~ ~ run kill @s
execute unless entity c9e31925-0471-4244-834f-c92ea4c7b87b at @s run summon marker ~ ~ ~ {UUID: [I; -907863771, 74531396, -2091923154, -1530414981], Tags: ["eroxified2.entity.fixed_uuid_entity"]}

function eroxified2:core/internal/unittests/test/check_if_macro_works/run/macro {cmd: "scoreboard players set #core.unittest eroxified2.internal 1"}

$$(cmd)

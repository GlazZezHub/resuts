scoreboard players set #core.unittest eroxified2.internal 0
function #eroxified2:core/internal/unittests/test/check_if_macro_works/run
execute unless score #core.unittest eroxified2.internal matches 1 run data modify storage eroxified2:internal eroxified2.failed_tests append value "check_if_macro_works"

scoreboard objectives add eroxified2.internal dummy
scoreboard objectives add eroxified2.api dummy
scoreboard objectives add eroxified2.leave_game minecraft.custom:minecraft.leave_game
data modify storage eroxified2:internal eroxified2 set value {version: "2.0.0", failed_tests: []}
scoreboard players reset @a eroxified2.leave_game
scoreboard players set #core.load_fault eroxified2.internal 0
scoreboard players set #core.load_complete eroxified2.internal 0
scoreboard players set #eroxified2.installed_version eroxified2.internal 2000000
function #eroxified2:core/load_modules
function #eroxified2:core/preload_packs
function #eroxified2:core/internal/unittests
execute if data storage eroxified2:internal eroxified2.failed_tests[0] run return run function eroxified2:core/internal/load/nested_return_0
scoreboard players set #core.load_complete eroxified2.internal 1
function #eroxified2:core/load_packs
function eroxified2:core/internal/load/wait_for_player
function eroxified2:core/internal/tick

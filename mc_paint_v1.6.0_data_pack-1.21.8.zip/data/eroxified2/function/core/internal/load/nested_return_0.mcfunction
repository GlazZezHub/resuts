tellraw @a {text: "[Eroxified2] Tests failed during load: ", color: "red", extra: [{storage: "eroxified2:internal", nbt: "eroxified2.failed_tests[]", separator: ", "}]}
scoreboard players set #core.load_complete eroxified2.internal -1

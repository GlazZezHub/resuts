function #eroxified2:core/load_modules_player
function #eroxified2:core/load_packs_player

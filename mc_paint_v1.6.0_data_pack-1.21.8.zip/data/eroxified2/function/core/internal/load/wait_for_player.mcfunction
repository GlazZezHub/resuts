execute unless entity @a run schedule function eroxified2:core/internal/load/wait_for_player 1 replace
execute if entity @a run function eroxified2:core/internal/load/first_player

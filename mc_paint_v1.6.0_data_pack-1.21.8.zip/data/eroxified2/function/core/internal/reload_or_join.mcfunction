advancement revoke @s only eroxified2:core/internal/reload_or_join
execute if score #core.load_complete eroxified2.internal matches 0 run return 0
execute if score #core.load_complete eroxified2.internal matches 1 run function #eroxified2:core/player_joined
scoreboard players set @s eroxified2.leave_game 42

advancement revoke @s from eroxified2:core/revoke_on_join

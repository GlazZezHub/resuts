scoreboard objectives remove eroxified2.internal
scoreboard objectives remove eroxified2.api
scoreboard objectives remove eroxified2.leave_game

schedule function eroxified2:datafixer/clock 79 replace
execute as @a[gamemode=!spectator] at @s run function #eroxified2:datafixer/clock_player

scoreboard objectives add eroxified2.datafixer_version dummy
schedule function eroxified2:datafixer/clock 21 replace

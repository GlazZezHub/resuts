function eroxified2:entity/internal/get_uuid/from_cache with entity @s
execute if data storage eroxified2:internal entity.uuid.cache_item run data modify storage eroxified2:api entity.get_uuid set from storage eroxified2:internal entity.uuid.cache_item
execute unless data storage eroxified2:internal entity.uuid.cache_item run function eroxified2:entity/internal/get_uuid/cache_miss

function eroxified2:fixed_uuid_entities/internal/entity/marker/init
data modify storage eroxified2:internal temp set value {}
data modify storage eroxified2:internal temp.x set from storage eroxified2:api entity.pos[0]
data modify storage eroxified2:internal temp.y set from storage eroxified2:api entity.pos[1]
data modify storage eroxified2:internal temp.z set from storage eroxified2:api entity.pos[2]
execute as c9e31925-0471-4244-834f-c92ea4c7b87b at @s run function eroxified2:entity/internal/pos_to_rotation with storage eroxified2:internal temp

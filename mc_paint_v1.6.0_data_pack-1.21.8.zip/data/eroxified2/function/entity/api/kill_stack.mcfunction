execute on passengers run function eroxified2:entity/api/kill_stack
kill @s

scoreboard players set #entity.height eroxified2.internal 0
execute at @s run function eroxified2:entity/internal/get_height/1
execute store result storage eroxified2:api entity.get_height float 0.0078125 run scoreboard players get #entity.height eroxified2.internal

function eroxified2:fixed_uuid_entities/internal/entity/item_display/init
loot replace entity addd48d0-2bf5-42ef-a425-f5e31ae6092e container.0 loot eroxified2:entity/internal/get_player_name
data modify storage eroxified2:api entity.player.get_name set from entity addd48d0-2bf5-42ef-a425-f5e31ae6092e item.components."minecraft:profile".name

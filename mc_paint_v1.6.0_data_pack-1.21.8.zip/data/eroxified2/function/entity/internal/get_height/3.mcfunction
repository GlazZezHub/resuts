execute positioned ~ ~8 ~ unless entity @s[dy=1] positioned ~ ~-8 ~ run return run function eroxified2:entity/internal/get_height/4
scoreboard players add #entity.height eroxified2.internal 1024
execute positioned ~ ~8 ~ run function eroxified2:entity/internal/get_height/4

execute positioned ~ ~0.5 ~ unless entity @s[dy=1] positioned ~ ~-0.5 ~ run return run function eroxified2:entity/internal/get_height/8
scoreboard players add #entity.height eroxified2.internal 64
execute positioned ~ ~0.5 ~ run function eroxified2:entity/internal/get_height/8

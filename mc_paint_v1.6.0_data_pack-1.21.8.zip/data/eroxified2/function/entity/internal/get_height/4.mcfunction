execute positioned ~ ~4 ~ unless entity @s[dy=1] positioned ~ ~-4 ~ run return run function eroxified2:entity/internal/get_height/5
scoreboard players add #entity.height eroxified2.internal 512
execute positioned ~ ~4 ~ run function eroxified2:entity/internal/get_height/5

execute positioned ~ ~1 ~ unless entity @s[dy=1] positioned ~ ~-1 ~ run return run function eroxified2:entity/internal/get_height/7
scoreboard players add #entity.height eroxified2.internal 128
execute positioned ~ ~1 ~ run function eroxified2:entity/internal/get_height/7

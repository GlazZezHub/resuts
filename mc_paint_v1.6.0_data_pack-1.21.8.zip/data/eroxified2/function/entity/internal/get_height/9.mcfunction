execute positioned ~ ~0.125 ~ unless entity @s[dy=1] positioned ~ ~-0.125 ~ run return run function eroxified2:entity/internal/get_height/10
scoreboard players add #entity.height eroxified2.internal 16
execute positioned ~ ~0.125 ~ run function eroxified2:entity/internal/get_height/10

execute positioned ~ ~0.0625 ~ unless entity @s[dy=1] positioned ~ ~-0.0625 ~ run return run function eroxified2:entity/internal/get_height/11
scoreboard players add #entity.height eroxified2.internal 8
execute positioned ~ ~0.0625 ~ run function eroxified2:entity/internal/get_height/11

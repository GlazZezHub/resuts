execute positioned ~ ~0.25 ~ unless entity @s[dy=1] positioned ~ ~-0.25 ~ run return run function eroxified2:entity/internal/get_height/9
scoreboard players add #entity.height eroxified2.internal 32
execute positioned ~ ~0.25 ~ run function eroxified2:entity/internal/get_height/9

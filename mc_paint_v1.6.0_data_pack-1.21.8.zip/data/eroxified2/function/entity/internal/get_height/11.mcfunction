execute positioned ~ ~0.03125 ~ unless entity @s[dy=1] positioned ~ ~-0.03125 ~ run return run function eroxified2:entity/internal/get_height/12
scoreboard players add #entity.height eroxified2.internal 4
execute positioned ~ ~0.03125 ~ run function eroxified2:entity/internal/get_height/12

execute positioned ~ ~16 ~ unless entity @s[dy=1] positioned ~ ~-16 ~ run return run function eroxified2:entity/internal/get_height/3
scoreboard players add #entity.height eroxified2.internal 2048
execute positioned ~ ~16 ~ run function eroxified2:entity/internal/get_height/3

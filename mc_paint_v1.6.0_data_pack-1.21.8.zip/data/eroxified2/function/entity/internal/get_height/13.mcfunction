execute positioned ~ ~0.0078125 ~ if entity @s[dy=1] run scoreboard players add #entity.height eroxified2.internal 1

execute positioned ~ ~32 ~ unless entity @s[dy=1] positioned ~ ~-32 ~ run return run function eroxified2:entity/internal/get_height/2
scoreboard players add #entity.height eroxified2.internal 4096
execute positioned ~ ~32 ~ run function eroxified2:entity/internal/get_height/2

execute positioned ~ ~2 ~ unless entity @s[dy=1] positioned ~ ~-2 ~ run return run function eroxified2:entity/internal/get_height/6
scoreboard players add #entity.height eroxified2.internal 256
execute positioned ~ ~2 ~ run function eroxified2:entity/internal/get_height/6

execute positioned ~ ~0.015625 ~ unless entity @s[dy=1] positioned ~ ~-0.015625 ~ run return run function eroxified2:entity/internal/get_height/13
scoreboard players add #entity.height eroxified2.internal 2
execute positioned ~ ~0.015625 ~ run function eroxified2:entity/internal/get_height/13

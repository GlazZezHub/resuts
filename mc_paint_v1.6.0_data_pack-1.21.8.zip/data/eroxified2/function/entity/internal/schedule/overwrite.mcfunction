$data remove storage eroxified2:internal entity.scheduled_events[{entity:"$(entity)",id:"$(id)"}]

$execute as $(entity) at @s run $(command)

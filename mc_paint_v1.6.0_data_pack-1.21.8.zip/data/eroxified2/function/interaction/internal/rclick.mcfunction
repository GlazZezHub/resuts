advancement revoke @s only eroxified2:interaction/internal/rclick
execute at @s anchored eyes positioned ^ ^ ^4 run function eroxified2:interaction/internal/rclick/search

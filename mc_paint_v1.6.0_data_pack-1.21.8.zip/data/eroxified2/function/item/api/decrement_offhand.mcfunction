item modify entity @s weapon.offhand {function: "minecraft:set_count", count: -1, add: true}

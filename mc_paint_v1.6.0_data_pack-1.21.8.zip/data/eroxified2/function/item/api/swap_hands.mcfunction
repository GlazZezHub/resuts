execute if items entity @s weapon.mainhand * unless items entity @s weapon.offhand * run return run function eroxified2:item/internal/swap_hands/mto
execute if items entity @s weapon.offhand * unless items entity @s weapon.mainhand * run return run function eroxified2:item/internal/swap_hands/otm
function eroxified2:fixed_uuid_entities/internal/entity/item_display/init
item replace entity addd48d0-2bf5-42ef-a425-f5e31ae6092e contents from entity @s weapon.mainhand
item replace entity @s weapon.mainhand from entity @s weapon.offhand
item replace entity @s weapon.offhand from entity addd48d0-2bf5-42ef-a425-f5e31ae6092e contents

stopsound @s * minecraft:entity.lingering_potion.throw
